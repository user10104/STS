package org.zerock.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.BoardVO;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Slf4j
public class BoardMapperTests {

   @Autowired
   private BoardMapper boardMapper;

   @Test
   public void testGetList() {
//      List<BoardVO> list = boardMapper.getList();
//      for(BoardVO vo : list)
//         log.info("vo: {}", vo);
//      위 아래 방법 모두 가능:
      boardMapper.getList().forEach((vo)->{
         log.info("vo: {}", vo);
      });
   }
   
   @Test
   public void testInsert() {
      BoardVO vo = new BoardVO();
      
      vo.setTitle("Java");
      vo.setContent("빡세게 자바 공부중");
      vo.setWriter("남궁성");
      
      int result = boardMapper.insert(vo);
      
      log.info("result: {}", result);
   }

   @Test
   public void testUpdate() {
      BoardVO vo = new BoardVO();
      
      vo.setBno(9L);
      vo.setTitle("Spring");
      vo.setContent("spring");
      vo.setWriter("이름");
      
      int result = boardMapper.update(vo);
      
      log.info("result: {}", result);
   }
   
   @Test 
   public void testRead() {
      BoardVO vo = boardMapper.read(4L);
      log.info("vo: {}", vo);
   }
   
   @Test
   public void testInsertSelecKey() {
	   BoardVO vo = new BoardVO();
	   
	   vo.setTitle("react");
	   vo.setContent("리액트 공부중");
	   vo.setWriter("jojo");
	   
	   int result = boardMapper.insertSelectKey(vo);
	   log.info("result : {} ", result);
   }
   
}














