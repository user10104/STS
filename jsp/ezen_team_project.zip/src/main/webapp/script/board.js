function open_win(url, name){
	window.open(url, name, "width=500, height=200");
}